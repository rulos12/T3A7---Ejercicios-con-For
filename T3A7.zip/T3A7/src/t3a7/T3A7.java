package t3a7;

import java.util.Scanner;

/**
 * * @author Raul
 */
public class T3A7 {

    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        ejercicio3();
        //ejercicio4();
    }

    public static void ejercicio1() {
        //Solicitar una cantidad determinada de números secuenciales y calcular la suma total de estos.
        Scanner obj = new Scanner(System.in);
        System.out.println("Ingrese una cantidad de numeros que quieres sumar ");
        int l = obj.nextInt();
        System.out.println("Desde que numero quieres empezar");
        int num=obj.nextInt();

        int suma = 0;

        for (int i = 1; i <= l; i++) {
            suma=num+suma;
            System.out.println("Ingrese otro numero");
            num=obj.nextInt();
        }
        System.out.println("La suma de los numeros es "+suma);
    }

    public static void ejercicio2() {
        //Pedir los primero 10 números impares y calcular el producto.
        Scanner obj = new Scanner(System.in);
        int mult=1;
        for (int i = 1; i <= 10; i++) {
            System.out.println("Ingrese un numero impar");
            int num = obj.nextInt();
            if (num % 2 == 0) {
                System.out.println("Este numero no es valido ya que es divisible entre 2");
            } else {
                mult = num*mult;
            }
        }
        System.out.println("El producto de los numeros impares es: "+mult);
        
    }

    public static void ejercicio3() {
        //Registrar una cantidad determinada de trabajadores: nombre y salario. 
        //Luego, calcular el promedio de los salarios.
        Scanner obj = new Scanner(System.in);
        String nom;
        int t, salario=0,p=0;
        System.out.println("Ingrese la cantidad de trabajadores que desea registrar");
        t = obj.nextInt();
       
        for (int i = 1; i <= t; i++) {
            System.out.println("Ingrese el nombre del trabajador");
            nom = obj.next();
            
            System.out.println("Ingrese el salario del trabajador");
            salario=obj.nextInt();
            
            
             System.out.println(nom+"       "+salario);
             p=salario+salario;
        }
        p=p/t;
        System.out.println("El salario promedio es: "+ salario );

    }

    public static void ejercicio4() {
        //Dadas las edades y alturas de 5 alumnos, mostrar la edad y la estatura media, 
        //la cantidad de alumnos mayores de 18 años, y la cantidad de alumnos que miden más de 1.75.
        Scanner obj = new Scanner(System.in);
        String nom;
        int edad, p2=0,p3=0;
        float estatura, promedio=0, p4=0;
        for (int i = 1; i <= 5; i++) {
            //System.out.println("Ingrese el nombre del alumno ");
            //nom = obj.nextLine();
            System.out.println("Ingrese la edad del alumno");
            edad = obj.nextInt();
            System.out.println("Ingrese la estatura del alumno en centimentros");
            estatura = obj.nextFloat();
            promedio=promedio+estatura;
            p2=p2+edad;
            if (edad>=18){
                p3++;
            }
            if(estatura>=1.75){
                p4++;
            }
        }
        promedio=promedio/5;
        p2=p2/5;
        System.out.println("El promedio es: "+ promedio);
        System.out.println("El promedio de edad es: "+p2);
        System.out.println("La cantidad de alumnos que tienen mayor de 18 años es: "+p3);
        System.out.println("la cantidad de alumnos que miden mas de 1.75m es: "+p4);
   }

}
